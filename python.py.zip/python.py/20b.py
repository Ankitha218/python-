print("Name: Rathod Ankitha \nEnrollment: 92600565030")

class Animal:

    def sound(self):
        print("Animal makes a sound")


class Dog(Animal):

    def sound(self):
        print("Dog barks")


animal = Animal()
animal.sound()

dog = Dog()
dog.sound()