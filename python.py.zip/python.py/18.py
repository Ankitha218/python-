print("Name: Rathod Ankitha \nEnrollment: 92600565030")

class Student:

    def display(self):
        print("Student Name is: Ankitha")
        print("Student Course is: MSc Cybersecurity")

student1 = Student()

student1.display()