num1 = int(input("Enter the 1st number: "))
num2 = int(input("Enter the 2nd number: "))

print(f"before swapping the values are num1: {num1} num2: {num2}")

num1,num2=num2,num1

print(f"After swapping the values are num1: {num1} num2: {num2}")

