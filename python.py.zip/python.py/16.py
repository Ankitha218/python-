class Student:
    def display(self):
        print("Student Name is: Ankiths")
        print("Student Course is: MSc Cybersecurity")
        print("Student Age is: 23")

student1 = Student()

student1.display()
