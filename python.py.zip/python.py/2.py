
num1 = int(input("Enter the First number: "))
num2 = int(input("Enter the Second number: "))

print("The addition is :)  ",num1+num2)
print("The substraction is :)  ",num1-num2)
print("The multiplication is :)  ",num1/num2)
print("The division is :)  ",num1*num2)
print("The modulus is :)  ",num1%num2)
