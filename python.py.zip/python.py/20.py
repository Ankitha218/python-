print("Name: Rathod Ankitha \nEnrollment: 92600565030")

class Addition:

    def add(self, num1, num2, num3=0):
        print("The addition is: ", num1 + num2 + num3)


addition = Addition()

addition.add(10, 20)

addition.add(10, 20, 30)