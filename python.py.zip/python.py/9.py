arr = [10, 2, 30, 4, 50]

sum = 0

for i in arr:
    sum += i

print("Sum of all elements:",sum)
