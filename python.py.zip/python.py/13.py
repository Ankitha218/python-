student = {
    "Name": "Rathod Ankitha",
    "Age": 23,
    "Course": "MSc Cybersecurity"
}

print("The dictionary is: ", student)
print("The keys are: ", student.keys())
print("The values are: ", student.values())
print("The items are: ", student.items())

student["City"] = "Ahmedabad"

print("After adding City: ", student)

student.pop("Age")

print("After removing Age: ", student)

print("The length of dictionary is: ", len(student))