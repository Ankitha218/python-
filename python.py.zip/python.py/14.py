def addition(num1, num2):
    result = num1 + num2
    print("The addition is: ", result)


num1 = int(input("Enter the First number: "))
num2 = int(input("Enter the Second number: "))

addition(num1, num2)